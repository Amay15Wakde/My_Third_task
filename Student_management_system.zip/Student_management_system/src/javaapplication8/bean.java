/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication8;
import java.util.*;
/**
 *
 * @author Asus
 */
public class bean {
    int roll_no;
    String first_name;
    String last_name;
    String mobile;
    String email;
    String address ;
    String dob;
    String course;
    int semester;
    String confirmPassword;
    String password;
    String message;
    void setRoll_no(int n)
    {
        this.roll_no = n;
    }
    int getRoll_no()
    {
        return roll_no;
    }
    void setfirst_name(String first_name)
    {
        this.first_name = first_name;
    }
    String getfirst_name()
    {
        return first_name;
    }
    void setlast_name(String last_name)
    {
        this.last_name = last_name;
    }
    String getlast_name()
    {
        return last_name;
    }
     void setmobile(String mobile)
    {
        this.mobile = mobile;
    }
    String getmobile()
    {
        return mobile;
    }
     void setemail(String email)
    {
        this.email = email;
    }
    String getemail()
    {
        return email;
    }
    void setaddress(String address)
    {
        this.address = address;
    }
    String getaddress()
    {
        return address;
    }
    void setdob(String dob)
    {
        this.dob = dob;
    }
    String getdob()
    {
        return dob;
    }
      void setcourse(String course)
    {
        this.course = course;
    }
    String getcourse()
    {
        return course;
    }
     void setsemester(int semester)
    {
        this.semester = semester;
    }
    int getsemester()
    {
        return semester;
    }
     void setpassword(String password)
    {
        this.password = password;
    }
    String getpassword()
    {
        return password;
    }
    
    void setconfirmPassword(String password)
    {
        this.confirmPassword = password;
    }
    String getconfirmPassword()
    {
        return confirmPassword;
    }
    void setmessage(String message)
    {
        this.message = message;
    }
    String getmessage()
    {
        return message;
    }
    
    
}
