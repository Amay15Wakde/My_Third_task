package javaapplication8;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.*;
import java.net.*;
import java.sql.*;

/**
 *
 * @author HP
 */
class ServerManager extends Thread{
    private Socket stk;
    private Connection con;
    private int count;
    
    public ServerManager(Socket st,Connection conn,int count){
        stk=st;
        con=conn;
        this.count=count;
        start();
    }
    
    public void run(){
        System.out.println("Client "+count+" started");

        try{
            
            DataInputStream in=new DataInputStream(stk.getInputStream());
            DataOutputStream out = new DataOutputStream(stk.getOutputStream());
            
            Statement st= con.createStatement();
            String query;
            ResultSet rs;
            
            while(true){
                
                String flag=in.readUTF();
                
                //login
                if(flag.equals("l")){
                      
                    int roll_no=Integer.parseInt(in.readUTF());
                    String p=in.readUTF();
                    
                    query="select password from users where roll_no=" +roll_no;
                    rs= st.executeQuery(query);
                    
                    if(rs.next()){
                            if(rs.getString("Password").equals(p))
                                    out.writeUTF("yes");

                            else
                                    out.writeUTF("no");
                    }
                    
                    else
                            out.writeUTF("no");
                }
bean info = new bean();
                //registration
//               System.out.println("start");
//                //if(flag.equals("yes")){
//                    String first_name=info.getfirst_name();
//                    String last_name=info.getlast_name();
//                    String mobile=info.getmobile();
//                    String email =info.getemail();
//                     String address=info.getaddress();
//                     String dob=info.getdob();
//                    String course=info.getcourse();
//                    int semester=(info.getsemester());
//                     String password = info.getpassword();
//                     System.out.println(first_name);
////                    query="select * from users where mobile = " + "'" + mobile + "'";
//                    //rs= st.executeQuery(query);
//                    System.out.println("wquerey");
//                    //if(rs.next()){ //MOBILE NUMBER ALREADY REGISTERED
////                        out.writeUTF("no");
//                    //}
//                    
////                    else{
//                        query="insert into users (first_name,last_name,mobile,email,address,dob,course,semester,password) values(?,?,?,?,?,?,?,?,?)";   
//                        PreparedStatement ps=con.prepareStatement(query);
//                        
//                        ps.setString(1,first_name);
//                        ps.setString(2,last_name);
//                        ps.setString(3,mobile);
//                        ps.setString(4,email);
//                        ps.setString(5,address);
//                        ps.setString(6,dob);
//                        ps.setString(7,course);
//                        ps.setInt(8,semester);
//                        ps.setString(9,password);
//                        System.out.println("mid");
//                        int  n= ps.executeUpdate();
//
//                        if(n>0){
//                                query="select roll_no from users where mobile=" + "'" + mobile+ "'" ;
//                                rs=st.executeQuery(query);                  
//                                rs.next();
//                                int roll_no = rs.getInt("roll_no");
//                                info.setRoll_no(roll_no);
//                                System.out.println(roll_no);
//                              //  info.setmessage("yes");
////                                out.writeUTF("yes");
////                                out.writeUTF(Integer.toString(rs.getInt("roll_no")));
////                        }
//                    }
//               // }
//                
                //fee_payment started
                if(flag.equals("std")){ //STUDENT DETAILS BUTTON

                    int id=Integer.parseInt(in.readUTF());
                    query="select name_of_student,class from student where roll_no=" +"id";
                    rs=st.executeQuery(query);
                    rs.next();
                    
                    String name =rs.getString("name_of_student");
                    String naam[]=name.split(" ");
                    int c =rs.getInt("class");

                    out.writeUTF(naam[0]);
                    out.writeUTF(Integer.toString(c));
                }
                
                if(flag.equals("ss")){ //SHOW STATUS BUTTON
                    int id=Integer.parseInt(in.readUTF());

                    query="select fee_status from student where id=" + id;
                    rs=st.executeQuery(query);
                    rs.next();
                    
                    out.writeUTF(rs.getString("fee_status"));
                }
                
                if(flag.equals("pay")){ //PAY NOW BUTTON
                    int id =Integer.parseInt(in.readUTF());
                    query ="select fee_status from student where id="+id;
                    rs = st.executeQuery(query);

                    rs.next();
                    String status=rs.getString("fee_status");
                    if(status.equals("unpaid")|| status.equals("UNPAID"))
                    {
                        query="update  student " +
                                    "set  fee_status='PAID' where id="+id;
                        int a= st.executeUpdate(query);
                        out.writeUTF("yes");
                    }
                    else{
                        out.writeUTF("no");
                    }
                }
            }//while ends
        }catch(Exception e){
            System.out.println("Client " + count+" terminated: " +e);
        }

        try{
            stk.close();
        }
        catch(Exception e){
            System.out.println("Closing client: "+e);
        }
    
    }
}


public class Server{

    public static void main(String[]args) {
        
        try{
                String url="jdbc:mysql://localhost:3306/fee_portal";
                String uname="root";
                String pass="Amay@9171";
                Connection con = DriverManager.getConnection(url,uname,pass);
                 System.out.println("hello");
                ServerSocket ss= new ServerSocket(8000);
                System.out.println("Server started");
                int count=1;
                System.out.println("Waiting for client..");
                 System.out.println("here we go");
                 Socket stk;
                do{
                    System.out.println("enter in do");
                     stk =ss.accept();
                    System.out.println("Client "+ count + " connected");
                    new ServerManager(stk,con,count++);
                }while(true);
            }catch(Exception e){
                System.out.println("Server: " + e);
        }
    }
}//void set(nboolean b)


