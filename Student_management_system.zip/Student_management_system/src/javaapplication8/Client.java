package javaapplication8;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.*;
import java.net.*;
/**
 *
 * @author HP
 */
public class Client {
 
    public static void main(String []args) {
        try{
                Socket stk =new Socket("localhost",8000);
                System.out.println("Connected");
                DataOutputStream out =new DataOutputStream(stk.getOutputStream());
                DataInputStream in=new DataInputStream(stk.getInputStream());

                home login=new home();  
                login.setVisible(true);
        }
        catch(Exception e){
            System.out.println("login" +e);
        }
    }
}
